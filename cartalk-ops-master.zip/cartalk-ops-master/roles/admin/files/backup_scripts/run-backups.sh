#!/bin/sh
/www/backups/scripts-sync/file-backup.sh
/www/backups/scripts-sync/docroot-backup.sh
#sleep 300
#/www/backups/scripts-sync/mysql-backup.sh
